"""Backend application package (FastAPI)."""
